# SnooNotesExtension

User notes and a whole lot more

## Installation

	$ npm install

## Usage

    $ npm run build:firefox
	
this will create the packaged files in a folder named "packages"





