import Vue from 'vue'

export const showNotesHub = new Vue();