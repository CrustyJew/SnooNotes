import requireDir from 'require-dir';

// Check out the tasks directory
// if you want to modify tasks!
requireDir('./tasks');
