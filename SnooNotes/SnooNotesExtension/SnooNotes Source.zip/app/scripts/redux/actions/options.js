

export const TOGGLE_SORT = "TOGGLE_SORT";

export const toggleSort = () =>{
    return {type: TOGGLE_SORT};
}

